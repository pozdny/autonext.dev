<?php
// HTTP
define('HTTP_SERVER', 'http://openk/admin/');
define('HTTP_CATALOG', 'http://openk/');

// HTTPS
define('HTTPS_SERVER', 'http://openk/admin/');
define('HTTPS_CATALOG', 'http://openk/');

// DIR
define('DIR_APPLICATION', 'Z:/home/openk/www/admin/');
define('DIR_SYSTEM', 'Z:/home/openk/www/system/');
define('DIR_LANGUAGE', 'Z:/home/openk/www/admin/language/');
define('DIR_TEMPLATE', 'Z:/home/openk/www/admin/view/template/');
define('DIR_CONFIG', 'Z:/home/openk/www/system/config/');
define('DIR_IMAGE', 'Z:/home/openk/www/image/');
define('DIR_CACHE', 'Z:/home/openk/www/system/cache/');
define('DIR_DOWNLOAD', 'Z:/home/openk/www/system/download/');
define('DIR_UPLOAD', 'Z:/home/openk/www/system/upload/');
define('DIR_LOGS', 'Z:/home/openk/www/system/logs/');
define('DIR_MODIFICATION', 'Z:/home/openk/www/system/modification/');
define('DIR_CATALOG', 'Z:/home/openk/www/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', '123');
define('DB_DATABASE', 'openk');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
