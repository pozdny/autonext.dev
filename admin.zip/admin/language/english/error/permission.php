<?php
// Heading
$_['heading_title']   = 'Permission Denied!';

// Text
$_['text_permission'] = 'You do not have permission to access this page, please refer to your system administrator.';