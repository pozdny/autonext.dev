<?php
$_['text_complete_status']   = 'Завершенных заказов'; 
$_['text_processing_status'] = 'Заказов в процессе'; 
$_['text_other_status']      = 'Другие заказы'; 

