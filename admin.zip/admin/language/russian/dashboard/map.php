<?php
// Heading
$_['heading_title'] = 'Карта мира';

$_['text_order']    = 'Заказов';
$_['text_sale']     = 'Продаж';

