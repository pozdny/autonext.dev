<?php
// Heading
$_['heading_title']    = 'PayPal Express Checkout Button';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified PayPal Express Checkout Button module!';
$_['text_edit']        = 'Edit PayPal Express Checkout Button Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify PayPal Express Checkout Button module!';

