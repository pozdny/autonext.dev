<?php
class ModelCatalogLinksPage extends Model {
    public function getLinkAd($num){
        $sql = "SELECT * FROM " . DB_PREFIX . "download_files WHERE number_sell_file = ".$num;
        $query = $this->db->query($sql);

        if ($query->num_rows) {
            return $query->rows;
        } else {
            return 0;
        }
    }

    public function updateLink($data = array()){
        if (!empty($data['id'])) {
            $id = $data['id'];
        }
        if (!empty($data['val'])) {
            $val = $data['val'];
        }
        else{
            $val = '';

        }
        $sql = "UPDATE ". DB_PREFIX ."download_files SET name_link = '" . $this->db->escape($val) . "' WHERE id_file_d =".$id;
        $query = $this->db->query($sql);

        return true;
    }
    public function deleteLinks($id){
        if (!empty($id)) {
            $links_id = $id;
        }

        $sql = "DELETE FROM ". DB_PREFIX ."download_files  WHERE id_file_d =".$links_id;
        $query = $this->db->query($sql);

        return true;
    }

}